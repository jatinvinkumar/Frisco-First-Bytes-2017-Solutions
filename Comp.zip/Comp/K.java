/*
 * Written By: Jatin K IHS
 */
import java.util.*;
import java.io.*;
import java.lang.*;
public class K{
    public static void main(String [] args) throws IOException{
        File file = new File("InputK.txt");
        Scanner kb = new Scanner(file);
        int n = kb.nextInt();
        kb.nextLine();
        for (int i = 0; i < n; i++){
            String a = kb.nextLine();
            String b = kb.nextLine();
            String[] arr1 = a.split("");
            String[] arr2 = b.split("");
            String str = "";
            int index = arr1.length; 
            String temp = "";
            boolean te = false;
            for (int j = 0; j <arr1.length; j++){
                if (arr1[j].equals(arr2[0]) && te == false){
                    temp = arr1[j];
                    te = true;
                    index = j;
                } 
                else if (arr1[j].equals(arr2[0]) && te == true && arr1[j].equals(temp)){
                    index = j;
                }
            }
            int index2 = 0;
            boolean check = false;
            for (int j = index; j<arr1.length; j++){
                if (arr2[index2].equals(arr1[j])){
                    index2 = index2 + 1;
                    check = true;
                } else {
                    j = arr1.length + 1;
                    break;
                }
            }
            
            for (int j = 0; j < index; j++){
                str = str + arr1[j];
            }
            
            if (check == false){
                str = str + b;
                System.out.println(str);
            } else {
                str = str + b.substring(index2);
                System.out.println(str);
            }
        }
    }
}