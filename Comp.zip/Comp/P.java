import java.util.*;
import java.lang.*;
import java.io.*;
public class P{
    public static void main(String [] args)throws IOException{
        File file = new File("PInput.txt");
        Scanner kd = new Scanner(file);
        int n = kd.nextInt();
        kd.nextLine();
        for (int i = 0; i<n; i++){
            int h = kd.nextInt();
            int w = kd.nextInt();
            boolean bonus = false;
            kd.nextLine();
            int[][] arr = new int[h][w];
            int max = h*w;
            System.out.println("gewd " + max);
            int h1 = 0;
            int w1 = 0;
            //load th3 2D array:
            for (int j = 0; j<h; j++){
                //kd.nextLine();
                
                for(int k = 0; k<w; k++){
                    int a = kd.nextInt();
                    
                    arr[j][k] = a;
                    if( arr[j][k] == 1){
                        h1 = j;
                        w1 = k;
                    }
                    System.out.print(arr[j][k] + " ");
                    
                }
                System.out.println("");
                
            }
            System.out.println(h1 + " ********* " + w1);
            //logic:
            int num = 1;
            for (int j = 0; j<16; j++){
                try{
                    if (arr[h1+1][w1] == (num + 1)){
                        h1 = h1 + 1;
                        num = num + 1;
                        System.out.println("down");
                        System.out.println(arr[h1][w1]);
                       
                    } else
                    if (arr[h1-1][w1] == (num + 1)){
                        h1 = h1 - 1;
                        num = num + 1;
                        System.out.println("up");
                        System.out.println(arr[h1][w1]);
                    }
                   
                    if (arr[h1][w1 - 1] == (num + 1)){
                        w1 = w1 - 1;
                        num = num + 1;
                        System.out.println("left");
                        System.out.println(arr[h1][w1]);
                    } else
                    if (arr[h1][w1 + 1] == (num + 1)){
                        w1 = w1 + 1;
                        num = num + 1;
                        System.out.println("right");
                        System.out.println(arr[h1][w1]);
                    }
                    
                } catch(Exception E){
                        
                } 
            }
            if (num == max){
                System.out.println("Bonus");
            }
            System.out.println(h1 + " ********* " + w1);
        }
    }
}