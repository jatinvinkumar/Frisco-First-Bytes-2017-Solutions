import java.util.*;
import java.lang.*;
import java.io.*;
public class Q{
    public static void main(String [] args) throws IOException{
        File file = new File("QInput.txt");
        Scanner kd = new Scanner(file);
        int n = kd.nextInt();
        
        kd.nextLine();
        for (int i = 0; i<n; i++){
            int h = kd.nextInt();
            int w = kd.nextInt();
            int portals = 0;
            kd.nextLine();
            String[][] arr = new String[h][w];
            
            //load th3 2D array:
            for (int j = 0; j<h; j++){
                String a = kd.nextLine();
                String[] str = a.split("");
                for(int k = 0; k<w; k++){
                    arr[j][k] = str[k];
                }
            }
            
            //logic:
            for (int j = 0; j<h; j++){
                for(int k = 0; k<w; k++){
                    
                    try{
                        //side check and dash check:
                        if (arr[j][k].equals("_") && arr[j][k-1].equals("*") && arr[j][k+1].equals("*") && arr[j+1][k].equals("*") && arr[j-1][k].equals("*")){
                            portals = portals + 1;
                        }
                    } catch(Exception E){
                        
                    } 
                }
            }
            if(portals > 0){
                System.out.println(portals + " Portals Found");
            } else {
                System.out.println("No Portals Found");
            }
        }
    }
}