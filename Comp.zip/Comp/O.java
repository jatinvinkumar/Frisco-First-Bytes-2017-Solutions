/*
 * Written By: Jatin Kumar IHS
 */
import java.util.*;
import java.lang.*;
import java.io.*;
public class O {
   public static void main(String [] args) throws IOException{
       File file = new File("inputO.txt");
       Scanner kb = new Scanner(file);
       int n = kb.nextInt();
       kb.nextLine();
       for (int i = 0; i < n; i++){
           String a = kb.nextLine();
           String [] arr = a.split("");
           int value = 0;
           for (int j = 0; j<arr.length; j++){
               //System.out.println(arr[j]);
               if(arr[j].equals("~") || arr[j].equals("<") || arr[j].equals(">")){
                   value = value + 1;
                }
           }
           System.out.println("Line #" + (i+1) + " will produce " + value + " Flotsam Fish Nuggets");
        }
   }
}