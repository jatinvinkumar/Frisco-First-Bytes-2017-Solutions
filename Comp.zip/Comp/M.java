import java.util.*;
import java.io.*;
public class M {
    public static void main(String [] args) throws IOException {
        File file = new File("mInput.txt");
        Scanner kb = new Scanner(file);
        int n = kb.nextInt();
        for (int i = 0; i<n; i++){
            double hour, min, sec = 0;
            hour = kb.nextInt();
            min = kb.nextInt();
            sec = kb.nextInt();
            int hour1 = (int)hour;
            int min1 = (int)min;
            int sec1 = (int)sec;
            
            hour = hour*3600;
            min = min*60;
            sec = hour + min + sec;
            double toHours = (sec)/(3600);
            int mph = (int)(((17.74)/(12 - toHours))+ 0.5);
            
            int kms = (int)((((double)mph)*((1.608934)))+0.5);
            System.out.println("If you leave at " + hour1 + " " + min1 + " " + sec1 + " , you will need to go  " + mph + " mph or " + kms + "km/s");
        }
    }
}