/*
 * Written By: Jatin K. IHS
 */
import java.util.*;
import java.lang.*;
import java.io.*;
public class N {
    public static void main(String [] args)throws IOException{
        File file = new File("nInput.txt");
        Scanner kb = new Scanner(file);
        int n = kb.nextInt();
        kb.nextLine();
        //Create a for loop for each block
        for (int i = 0; i<n; i++){
            System.out.println("Match #" + (i+1) + " Begin!");
            //Player names for each block
            String p1 = kb.nextLine();
            //System.out.println(p1);
            String p2 = kb.nextLine();
            //System.out.println(p2);
            int s1 = kb.nextInt();
            kb.nextLine();
            String[] arr1 = new String[s1];
            for (int j = 0; j<s1; j++){
                arr1[j] = kb.nextLine();
                //System.out.println(arr1[j]);
            }
            int s2 = kb.nextInt();
            kb.nextLine();
            String[] arr2 = new String[s2];
            for (int j = 0; j<s2; j++){
                arr2[j] = kb.nextLine();
                //System.out.println(arr2[j]);
            }
            //System.out.println("*****************************");
            if (s1>s2){
                for (int j = 0; j<s2; j++){
                    System.out.println(p1 + " uses " + arr1[j] + "!");
                    System.out.println(p2 + " uses " + arr2[j] + "!");
                } 
                System.out.println(p1 + " uses " + arr1[s1-1] + "!");
                System.out.println(p1 + " defeats " + p2 + " using " + arr1[s1 - 1] + "!");
            } else if (s2>s1) {
                for (int j = 0; j<s1; j++){
                    System.out.println(p1 + " uses " + arr1[j] + "!");
                    System.out.println(p2 + " uses " + arr2[j] + "!");
                } 
                System.out.println(p2 + " uses " + arr2[s2-1] + "!");
                System.out.println(p2 + " defeats " + p1 + " using " + arr2[s2 - 1] + "!");
            }
            //System.out.println("||||||||||||||||||||||||||||||||||||||");
        }
    }
}

    